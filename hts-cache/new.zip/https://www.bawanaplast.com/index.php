<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="utf-8">
        <title>Bawana Plast | Plastic Crates Manufacturer</title>
		<link rel="canonical" href="http://www.bawanaplast.com/"/>
		<link rel="shortcut icon" type="image/png" href="./img/favicon.png"/>
		<meta content="Bawana Plast is manufacturer of plastic crates like Industrial Crates, Milk Pouch Crates, Fruit Crates, Vegetables Crates and Bakery Crates. We supply all standard sizes and wights crates." name="description"/>
		<meta content="bawana plast, plastic crates manufacturer, industrial crates manufacturer, milk pouch crates manufacturer, fruit crates manufacturer, vegetables crates manufacturer, bakery crates manufacturer" name="keywords"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=latin-ext" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/nebula.css" rel="stylesheet">
    </head>
    <body>
        <header class="site-header">
    <div class="top">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <p> Bawana Plast Industries Pvt. Ltd.</p>
                </div>
                <div class="col-sm-6">
                    <ul class="list-inline pull-right">
                        <li class="phone"><a href="tel:+91-9873608702">+91 9873608702</a> <br></li>
                    </ul>                        
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-default">
        <div class="container">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <i class="fa fa-bars"></i>
            </button>
            <a href="http://www.bawanaplast.com/" class="navbar-brand"><img src="img/logo.png" alt="Bawana Plast"></a>
            <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                <ul class="nav navbar-nav main-navbar-nav">
                    <li  class="active"><a href="./index.php" title="">HOME</a></li>
                    <li class="" ><a href="./aboutus.php" title="">ABOUT US</a></li>
                    <li  class="dropdown">
                        <a href="#" title="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PRODUCTS<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li>
                                <a href="fruit.php">Fruit & Vegetables Crates</a>
                            </li>
                            <li>
                                <a href='ind.php'>Industrial Crates</a>
                            </li>
                            <li>
                                <a href='milk.php'>Milk Pouch Crates</a>
                            </li>
                           
                            <li>
                                <a href="bakery.php">Bakery Crates</a>
                            </li>

                           
                           
                        </ul>
                    </li>
                    <li class=""><a href="enquiry.php" title="">ENQUIRY</a></li>
                    <li class=""><a href="./contactus.php" title="">CONTACT</a></li>
                </ul>                           
            </div>   
        </div>
    </nav>        
</header>
        <main class="site-main">
            <section class="hero_area">
                <div id="myCarousel" class="carousel slide" data-pause="false" data-ride="carousel" data-interval="3000">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="img/slider1.jpg"  style="width:100%;" alt="Bawana Plast">
                        </div>

                        <div class="item">
                            <img src="img/slider2.jpg"  style="width:100%;" alt="Vegetables Crates">
                        </div>
						
						<div class="item">
                            <img src="img/slider3.jpg"  style="width:100%;" alt="Bakery Crates">
                        </div>

                     
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </section>
            <section class="boxes_area" style=" margin: 30px 0px; ">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="box home-top text-center">
                                <h2>OUR BRANDS</h2>
                                <div class="rwo text-center">
                                    <div class="home-top-item-red col-md-4"> <img src="img/red.jpg" alt="Red Fresh"> </div>
                                    <div class="home-top-item-blue col-md-4"><img src="img/blue.jpg" alt="Blue Fresh"></div>
                                    <div class="home-top-item-green col-md-4"> <img src="img/green.jpg" alt="Green Fresh"> </div>
                                </div>
                                
                            </div>
                        </div>

                    </div>
                </div>
            </section>
			<section class="home-area" style="background-color: #f2f2f2; margin: 40px 0px;padding:50px 0px 20px 0px;">
                <div class="container">
                    <div class="row"> 
                        <div class="col-sm-6">
                            <h2 class="text-uppercase" style="color: #404040;"><strong>About Bawana Plast Industries Pvt. Ltd.</strong></h2>
                            <p style="color: #404040;">Bawana Plast Industries Pvt. Ltd. is an ISO - 9001:2008 certified company established in 2009. We are dedicated to supplying the latest and highly engineered plastic crates for <strong>Fruits</strong>, <strong>Vegetable</strong>, <strong>Milk</strong>, <strong>Bakery</strong> and <strong>Industrial</strong> products supply. Depending upon the needs of your industry/service you may require specialized crates. Our crates are available in a wide range of sizes and volume to address needs of material used or produced by different companies.</p>
                        </div>
                        <div class="col-sm-6">
                            <div class="widget ">
                                <img class="img-responsive img-thumbnail" src="img/about2.jpg">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="home-area">
                <div class="home_content">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12"><h2>OUR PRODUCTS</h2></div>
                            <div class="home_list">
                                <ul>
                                   <li class="col-md-3 col-sm-6 col-xs-12">
                                        <div class="thumbnail list-quotes">
                                            <a href="fruit.php"> <img src="img/cat1.jpg" alt="Fruit Crate"></a>
                                          
                                        </div>                                        
                                    </li>
                                    <li class="col-md-3 col-sm-6 col-xs-12">
                                        <div class="thumbnail list-quotes">
                                            <a href="ind.php"> <img src="img/cat2.jpg" alt="Industrial Crate"></a>
                                        
                                        </div>                                        
                                    </li>
                                    <li class="col-md-3 col-sm-6 col-xs-12">
                                        <div class="thumbnail list-quotes">
                                            <a href="milk.php"> <img src="img/cat3.jpg" alt="Milk Pouch Crate"></a>
                                         
                                        </div>                                        
                                    </li>
                                    <li class="col-md-3 col-sm-6 col-xs-12">
                                        <div class="thumbnail list-quotes">
                                            <a href="bakery.php"> <img src="img/cat4.jpg" alt="Bakery Crate"></a>
                                           
                                        </div>                                        
                                    </li>
                                </ul>
                            </div>

                         
                        </div>
                    </div>
                </div>
            </section>

        </main>
        <footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 fbox">
                <h4>Bawana Plast</h4>
                <p class="text">Bawana Plast Industries Pvt. Ltd. is dedicated to supplying the latest and highly engineered plastic crates for Fruits, Vegetable, Milk, Bakery and Industrial products supply. Depending upon the needs of your industry/service you may require specialized crates.... <a href="http://www.bawanaplast.com/aboutus.php">Read more</a></p>
            </div>

            <div class="col-md-4 fbox">
                <h4>Quick Links</h4>
                <ul class="big">
                    <li>
                        <a href="http://www.bawanaplast.com/">Home</a>
                    </li>
					<li>
                        <a href='ind.php'>Industrial Crates</a>
                    </li>
                    <li>
                        <a href='aboutus.php'>About Us</a>
                    </li>
					<li>
                        <a href='milk.php'>Milk Pouch Crates</a>
                    </li>
                    <li>
                        <a href='enquiry.php'>Enquiry</a>
                    </li>
					<li>
                        <a href="fruit.php">Fruit & Vegetables Crates</a>
                    </li>
					<li>
                        <a href="contactus.php">Contact Us</a>
                    </li>
                    <li>
                        <a href="bakery.php">Bakery Crates</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-4 fbox">
                <h4>Contact Us</h4>
                <p class="text">
                    <b>Bawana Plast Industries Pvt. Ltd.</b><br>
                    G-7, Sector-2, Industrial Area, Bawana<br>
                  Delhi ( 110039 )
                </p>
                <p><a href="tel:+919873608702"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +91 9873608702</a></p>
                <p><a href="mailto:bawanaplastind@gmail.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> bawanaplastind@gmail.com</a></p>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <p>&copy; 2017 <a href="http://www.bawanaplast.com/">Bawana Plast</a> Industries Pvt. Ltd.</p>
                </div>
                <div class="col-md-4">
					<p class="pull-right">Developed by <a href="https://www.nebulainfotech.com/" target="_Blank">Nebula Infotech</a></p>
                </div>
            </div>
        </div>
    </div>        
</footer>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script type="text/javascript">
            $('.carousel[data-type="multi"] .item').each(function () {
                var next = $(this).next();
                if (!next.length) {
                    next = $(this).siblings(':first');
                }
                next.children(':first-child').clone().appendTo($(this));

                for (var i = 0; i < 4; i++) {
                    next = next.next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }

                    next.children(':first-child').clone().appendTo($(this));
                }
            });
        </script>
    </body>
</html>