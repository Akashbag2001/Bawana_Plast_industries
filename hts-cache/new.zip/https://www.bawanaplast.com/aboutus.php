<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/png" href="./img/favicon.png"/>
        <title>About Us | Bawana Plast</title>
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=latin-ext" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <header class="site-header">
    <div class="top">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <p> Bawana Plast Industries Pvt. Ltd.</p>
                </div>
                <div class="col-sm-6">
                    <ul class="list-inline pull-right">
                        <li class="phone"><a href="tel:+91-9873608702">+91 9873608702</a> <br></li>
                    </ul>                        
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-default">
        <div class="container">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <i class="fa fa-bars"></i>
            </button>
            <a href="http://www.bawanaplast.com/" class="navbar-brand"><img src="img/logo.png" alt="Bawana Plast"></a>
            <div class="collapse navbar-collapse" id="bs-navbar-collapse">
                <ul class="nav navbar-nav main-navbar-nav">
                    <li  class=""><a href="./index.php" title="">HOME</a></li>
                    <li class="active" ><a href="./aboutus.php" title="">ABOUT US</a></li>
                    <li  class="dropdown">
                        <a href="#" title="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PRODUCTS<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li>
                                <a href="fruit.php">Fruit & Vegetables Crates</a>
                            </li>
                            <li>
                                <a href='ind.php'>Industrial Crates</a>
                            </li>
                            <li>
                                <a href='milk.php'>Milk Pouch Crates</a>
                            </li>
                           
                            <li>
                                <a href="bakery.php">Bakery Crates</a>
                            </li>

                           
                           
                        </ul>
                    </li>
                    <li class=""><a href="enquiry.php" title="">ENQUIRY</a></li>
                    <li class=""><a href="./contactus.php" title="">CONTACT</a></li>
                </ul>                           
            </div>   
        </div>
    </nav>        
</header>
        <div class="bread_area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <ol class="breadcrumb">
                            <li><a href="http://www.bawanaplast.com/">Home</a></li>
                            <li class="active">About Us</li>
                        </ol>                    
                    </div>
                </div>
            </div>
        </div>
        <main class="site-main page-main">
            <div class="container">
                <div class="row">
                    <section class="page col-sm-8">
                        <h2 class="page-title">About Us</h2>
                    </section>
                    <section class="page col-sm-7">
                        <div class="entry text-justify">
                            <p>Bawana Plast Industries Pvt. Ltd. is an ISO - 9001:2008 certified company established in 2009. We are dedicated to supplying the latest and highly engineered plastic crates for <strong>Fruits</strong>, <strong>Vegetable</strong>, <strong>Milk</strong>, <strong>Bakery</strong> and <strong>Industrial</strong> products supply. Depending upon the needs of your industry/service you may require specialized crates. Our crates are available in a wide range of sizes and volume to address needs of material used or produced by different companies.</p>
                            <p>We believe in fully satisfying our client's needs for high quality and decently priced products. We only supply the absolute best, which is why our customers believe us to be the best suppliers of plastic crates in India.</p>
							<p><a href="http://www.bawanaplast.com/">Bawana Plast</a> can help you when you are searching for high-quality crates with best fit budget. Whether you and industrialist or vegetable / bakery products / milk products supplier, we have the crates available for you in all standard sizes and best quality</p>
							<p>As a plastic crate wholesale supplier in India we offer low prices on all our products. To find out more about our pricing or to receive a quote on the exact products you require, simply submit and online enquiry or call us now.</p>
                        </div>
                    </section>
                    <aside class="sidebar col-sm-5">
                        <div class="widget ">
                            <img class="img-responsive img-thumbnail" src="img/about.jpg">
                        </div>
                    </aside>
                </div>
            </div>
        </main>
        <footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 fbox">
                <h4>Bawana Plast</h4>
                <p class="text">Bawana Plast Industries Pvt. Ltd. is dedicated to supplying the latest and highly engineered plastic crates for Fruits, Vegetable, Milk, Bakery and Industrial products supply. Depending upon the needs of your industry/service you may require specialized crates.... <a href="http://www.bawanaplast.com/aboutus.php">Read more</a></p>
            </div>

            <div class="col-md-4 fbox">
                <h4>Quick Links</h4>
                <ul class="big">
                    <li>
                        <a href="http://www.bawanaplast.com/">Home</a>
                    </li>
					<li>
                        <a href='ind.php'>Industrial Crates</a>
                    </li>
                    <li>
                        <a href='aboutus.php'>About Us</a>
                    </li>
					<li>
                        <a href='milk.php'>Milk Pouch Crates</a>
                    </li>
                    <li>
                        <a href='enquiry.php'>Enquiry</a>
                    </li>
					<li>
                        <a href="fruit.php">Fruit & Vegetables Crates</a>
                    </li>
					<li>
                        <a href="contactus.php">Contact Us</a>
                    </li>
                    <li>
                        <a href="bakery.php">Bakery Crates</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-4 fbox">
                <h4>Contact Us</h4>
                <p class="text">
                    <b>Bawana Plast Industries Pvt. Ltd.</b><br>
                    G-7, Sector-2, Industrial Area, Bawana<br>
                  Delhi ( 110039 )
                </p>
                <p><a href="tel:+919873608702"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +91 9873608702</a></p>
                <p><a href="mailto:bawanaplastind@gmail.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> bawanaplastind@gmail.com</a></p>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <p>&copy; 2017 <a href="http://www.bawanaplast.com/">Bawana Plast</a> Industries Pvt. Ltd.</p>
                </div>
                <div class="col-md-4">
					<p class="pull-right">Developed by <a href="https://www.nebulainfotech.com/" target="_Blank">Nebula Infotech</a></p>
                </div>
            </div>
        </div>
    </div>        
</footer>        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>